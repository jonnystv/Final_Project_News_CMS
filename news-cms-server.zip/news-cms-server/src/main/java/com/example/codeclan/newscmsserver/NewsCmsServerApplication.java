package com.example.codeclan.newscmsserver;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class NewsCmsServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(NewsCmsServerApplication.class, args);
	}

}
